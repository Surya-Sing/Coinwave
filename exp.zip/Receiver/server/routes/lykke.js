const commonCollection = require('../models/common');
const express = require('express');
const http = require("https");
const router = express.Router();
const request = require("request");

const getData = (req, res) => {
    request({
        url: "https://public-api.lykke.com/api/Market",
        method: "GET",
    }, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log('success!');

            var date = new Date(),
                hours = date.getHours(),
                minutes = date.getMinutes();
            var dataLykke = JSON.parse(body.toString());
            for (var item in dataLykke) {

                var dataObj = {
                    name: "lykkeexchange",
                    pair: dataLykke[item].assetPair.toLowerCase(),
                    volume: dataLykke[item].volume24H == "N/A" ? 0 : dataLykke[item].volume24H,
                    price: dataLykke[item].lastPrice == "N/A" ? 0 : dataLykke[item].lastPrice,
                    low: dataLykke[item].bid == "N/A" ? 0 : dataLykke[item].bid,
                    high: dataLykke[item].ask == "N/A" ? 0 : dataLykke[item].ask,
                    date: date.toLocaleDateString(),
                    open: dataLykke[item].lastPrice != "N/A" ? (hours == 12 ? dataLykke[item].lastPrice : 0) : 0,
                    close: dataLykke[item].lastPrice != "N/A" ? (hours != 12 ? dataLykke[item].lastPrice : 0) : 0,
                }
                console.log(dataObj);


                var lykkeDetails = new commonCollection(dataObj);
                lykkeDetails.save(function (err, data) {
                    if (err) {
                        // console.log("ERROR: "+err)
                    } else {
                        // console.log("LykkeExchange Added Successfully")
                    }
                })


            }

        } else {
            console.log('error' + response.statusCode);
        }
    });
}





router.route('/').get(getData);
module.exports = router;
module.exports.getData = getData;
