const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://www.cryptopia.co.nz/api/GetMarkets'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
				
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date))
                    var cryptoData = JSON.parse(body.toString());
					if(cryptoData){
						
					if(cryptoData.hasOwnProperty('Data')){
                    var cryptopiaData = cryptoData.Data;
                    var ethCoin = cryptopiaData.find(function (element) {
                        if (element.Label == 'ETH/USDT') {
                            return element;
                        }
                    });
                    var btcCoin = cryptopiaData.find(function (element) {
                        if (element.Label == 'BTC/USDT') {
                            return element;
                        }
                    });

                    var pairName, convertUsd; var crptoArray = [];
                    cryptopiaData.map((item) => {

                        var coinPair = (item.Label).split('/');
                        if (coinPair[1] == 'USDT') {

                            pairName = (item.Label).replace(/\/usdt/gi, "usd").toLowerCase();
                            convertUsd = 1
                            var obj = {
                                name: "cryptopia",
                                pair: pairName,
                                volume: item.Volume * convertUsd,
                                price: item.LastPrice * convertUsd,
                                high: item.High * convertUsd,
                                open: item.Open * convertUsd,
                                close: item.Close * convertUsd,
                                low: item.Low * convertUsd,
                                datestamp: datestamp,
								lastRecord: true 
                            }

                            crptoArray.push(obj)

                        } else if (coinPair[1] == 'ETH') {

                            pairName = (item.Label).replace(/\/eth/gi, "usd").toLowerCase();
                            convertUsd = ethCoin.LastPrice;
                            var obj = {
                                name: "cryptopia",
                                pair: pairName,
                                volume: item.Volume * convertUsd,
                                price: item.LastPrice * convertUsd,
                                high: item.High * convertUsd,
                                open: item.Open * convertUsd,
                                close: item.Close * convertUsd,
                                low: item.Low * convertUsd,
                                datestamp: datestamp
                            }

                            crptoArray.push(obj)

                        } else if (coinPair[1] == 'BTC') {
                            pairName = (item.Label).replace(/\/btc/gi, "usd").toLowerCase();
                            convertUsd = btcCoin.LastPrice;
                            var obj = {
                                name: "cryptopia",
                                pair: pairName,
                                volume: item.Volume,
                                price: item.LastPrice * convertUsd,
                                high: item.High * convertUsd,
                                open: item.Open * convertUsd,
                                close: item.Close * convertUsd,
                                low: item.Low * convertUsd,
                                datestamp: datestamp
                            }

                            crptoArray.push(obj)

                        }

                    })
                    var flags = {};
                    var cryptopiaUniqueData = crptoArray.filter(function (entry) {
                        if (flags[entry.pair]) {
                            return false;
                        }
                        flags[entry.pair] = true;
                        return true;
                    });
                    commonCollection.insertMany(cryptopiaUniqueData, function (error, docs) {
                    });
					}
					}
                }
            }
        });

    } catch (error) {
    }
}

module.exports = router;
module.exports.getData = getData;

