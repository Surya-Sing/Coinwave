const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");

const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://ore.bz:443//api/v2/tickers.json'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    commonCollection.find({ name: "ore.bz", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;
                        var pairName, convertUsd, openPrice;
                        for (item in CoinData) {
                            var coinPair = (item).substr(item.length - 3);
                            if (coinPair == 'usd') {
                                convertUsd = 1
                                pairName = item;
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].ticker.last) * Number(convertUsd);

                                    }

                                } else {
                                    openPrice = Number(CoinData[item].ticker.last) * Number(convertUsd);
                                }

                            } else {
                                pairName = false;
                            }

                            if (pairName) {

                                var obj = {
                                    name: "ore.bz",
                                    pair: pairName,
                                    volume: Number(CoinData[item].ticker.vol) * convertUsd,
                                    price: Number(CoinData[item].ticker.last) * convertUsd,
                                    high: Number(CoinData[item].ticker.high) * convertUsd,
                                    open: Number(openPrice),
                                    close: Number(CoinData[item].ticker.last) * convertUsd,
                                    low: Number(CoinData[item].ticker.low) * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString
                                }
                                console.log(obj)
                                crptoArray.push(obj)
                            }
                        }
                        return res.send(crptoArray)
                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (entry.pair == 'usdtusd') {
                                return false;
                            }
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });

                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })


                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;
