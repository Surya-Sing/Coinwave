
const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.huobi.pro/market/tickers'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {


                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    try {
                        var cryptoData = JSON.parse(body.toString());
                    } catch (e) {
                        return false;
                    }
                    var CoinData = cryptoData.data;

                    if (CoinData) {
                        var ethCoin = CoinData.find(function (element) {
                            if (element.symbol == 'ethusdt') {
                                return element;
                            }
                        });
                        var btcCoin = CoinData.find(function (element) {
                            if (element.symbol == 'btcusdt') {
                                return element;
                            }
                        });

                        var coinDetail = coinDetail;
                        var pairName, convertUsd, openPrice;
                        CoinData.map((item) => {
                            var pairNameComvert = (item.symbol).replace(/usdt/gi, "usd").toLowerCase();
                            var coinPair = pairNameComvert.substr(pairNameComvert.length - 3);

                            if (coinPair == 'usd') {
                                convertUsd = 1
                                pairName = (item.symbol).replace(/usdt/gi, "usd").toLowerCase();


                            } else if (coinPair == 'eth') {
                                if (ethCoin) {
                                    pairName = (item.symbol).replace(/eth/gi, "usd").toLowerCase();
                                    convertUsd = ethCoin.amount;
                                }

                            } else if (coinPair == 'btc') {
                                if (btcCoin) {
                                    pairName = (item.symbol).replace(/btc/gi, "usd").toLowerCase();
                                    convertUsd = btcCoin.amount;

                                }
                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "huobi",
                                    pair: pairName,
                                    volume: item.vol * convertUsd,
                                    price: item.amount * convertUsd,
                                    high: item.high * convertUsd,
                                    open: item.open,
                                    close: item.close * convertUsd,
                                    low: item.low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
                                    lastRecord: true
                                }
                                crptoArray.push(obj)


                            }

                        })

                        var flags = {};

                        var CoinUniqueData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                       
                        commonCollection.insertMany(CoinUniqueData, function (error, docs) {
                            //console.log("OK")
                        });

                    }

                }
            }
        });

    } catch (error) {
    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;
