const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");


const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.gdax.com/products/stats',
            agent: false,
            headers: {
                'User-Agent': 'something',
            }
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    for (item in CoinData) {
                        var coinPair = item.split('-');

                        if (coinPair[1] == 'USD') {
                            pairName = (item).replace(/-usd/gi, "usd").toLowerCase();
                            var obj = {
                                name: "gdax",
                                pair: pairName,
                                volume: CoinData[item].stats_24hour.volume,
                                price: CoinData[item].stats_24hour.last,
                                high: CoinData[item].stats_24hour.high,
                                open: CoinData[item].stats_24hour.open,
                                close: CoinData[item].stats_24hour.last,
                                low: CoinData[item].stats_24hour.low,
                                datestamp: datestamp,
								lastRecord: true
                            }

                            crptoArray.push(obj)
                        }
                    }

                    commonCollection.insertMany(crptoArray, function (error, docs) {
                       
                    });



                }
            }



        });

    } catch (error) {

    }
}



router.route('/').get(getData)


module.exports = router;
module.exports.getData = getData;


