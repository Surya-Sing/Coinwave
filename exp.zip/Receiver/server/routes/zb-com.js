const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'http://api.zb.cn/data/v1/allTicker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {


                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());

                    var ethCoin = CoinData.ethusdt;
                    var btcCoin = CoinData.btcusdt;
                    commonCollection.find({ name: "zb.com", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;
                       
                        var pairName, convertUsd, openPrice;
                        for (item in CoinData) {
                           var pairNameComvert = (item).replace(/usdt/gi, "usd").toLowerCase();
                            var coinPair = pairNameComvert.substr(pairNameComvert.length - 3);
                          
                            if (coinPair == 'usd') {
                                convertUsd = 1;
                                pairName = (item).replace(/usdt/gi, "usd").toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;

                                    }

                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }

                            } else if (coinPair == 'eth') {
                                pairName =  item.slice(0, -3) + 'usd';
                               // pairName = (item).replace(/eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;
                                    }

                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }
                            } else if (coinPair == 'btc') {
                                pairName =  item.slice(0, -3) + 'usd';
                                //pairName = (item).replace(/btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;
                                    }
                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }

                            } else {
                                pairName = false;
                            }

                            if (pairName) {
                                var obj = {
                                    name: "zb.com",
                                    pair: pairName,
                                    volume: CoinData[item].vol * convertUsd,
                                    price: CoinData[item].last * convertUsd,
                                    high: CoinData[item].high * convertUsd,
                                    open: openPrice,
                                    close: CoinData[item].last * convertUsd,
                                    low: CoinData[item].low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString
                                }
                                crptoArray.push(obj)
                            }
                        }
                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                       
                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })


                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData);

module.exports = router;
module.exports.getData = getData;
