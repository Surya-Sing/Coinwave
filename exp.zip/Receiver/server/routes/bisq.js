const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");

const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://markets.bisq.network/api/ticker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    var btcCoin = CoinData.btc_usd;

                    commonCollection.find({ name: "bisq", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        for (item in CoinData) {
                            console.log(CoinData[item])
                            if (CoinData[item]){ 
                            var coinPair = item.split('_');
                            if (coinPair[1] == 'usd') {

                                convertUsd = 1
                                pairName = (item).replace(/_usd/gi, "usd").toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].last) * convertUsd;
                                    }

                                } else {
                                    openPrice = Number(CoinData[item].last) * convertUsd;
                                }

                            } else if (coinPair[1] == 'btc') {
                                pairName = (item).replace(/_btc/gi, "usd").toLowerCase();
                                convertUsd = Number(btcCoin.last);
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {

                                        openPrice = Number(CoinData[item].last) * convertUsd;
                                    }

                                } else {
                                    openPrice = Number(CoinData[item].last) * convertUsd;
                                }

                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "bisq",
                                    pair: pairName,
                                    volume: Number(CoinData[item].volume_right) * convertUsd,
                                    price: Number(CoinData[item].last) * convertUsd,
                                    high: CoinData[item].high * convertUsd,
                                    open: openPrice,
                                    close: Number(CoinData[item].last) * convertUsd,
                                    low: Number(CoinData[item].low) * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString
                                }
                                
                                crptoArray.push(obj)


                            }

                        }
                        }

                        var flags = {};

                        var coinUniqueData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                      
                        commonCollection.insertMany(coinUniqueData, function (error, docs) {

                        });
                    })


                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;
