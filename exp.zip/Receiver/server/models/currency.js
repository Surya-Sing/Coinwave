
var mongoose = require('mongoose');

var currency = mongoose.Schema({
    currency: {
        type: Array,
        default:[]
    }

});


module.exports = mongoose.model('currency', currency);
module.exports.schema = currency;

