
const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.gatecoin.com/v1/Public/LiveTicker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var cryptoData = JSON.parse(body.toString());
                    var CoinData = cryptoData.tickers;
                    var ethCoin = CoinData.find(function (element) {
                        if (element.currencyPair == 'ETHUSD') {
                            return element;
                        }
                    });
                    var btcCoin = CoinData.find(function (element) {
                        if (element.currencyPair == 'BTCUSD') {
                            return element;
                        }
                    });
                    var pairName, convertUsd, openPrice;
                    CoinData.map((item) => {
                        var coinPair = (item.currencyPair).substr(item.currencyPair.length - 3);
                        //console.log(coinPair)
                        if (coinPair == 'USD') {
                            convertUsd = 1
                            pairName = (item.currencyPair).replace(/usd/gi, "usd").toLowerCase();
                        } else if (coinPair == 'ETH') {
                            pairName = (item.currencyPair).replace(/eth/gi, "usd").toLowerCase();
                            convertUsd = ethCoin.last;

                        } else if (coinPair == 'BTC') {
                            pairName = (item.currencyPair).replace(/btc/gi, "usd").toLowerCase();
                            convertUsd = btcCoin.last;


                        } else {
                            pairName = false;
                        }
                        if (pairName) {

                            var obj = {
                                name: "gatecoin",
                                pair: pairName,
                                volume: item.volume * convertUsd,
                                price: item.last * convertUsd,
                                high: item.high * convertUsd,
                                open: item.open * convertUsd,
                                close: item.last * convertUsd,
                                low: item.low * convertUsd,
                                datestamp: datestamp,
                                date: dateString
                            }
                            crptoArray.push(obj)


                        }

                    })

                    var flags = {};
                    var UniqueCoinData = crptoArray.filter(function (entry) {
                        if (flags[entry.pair]) {
                            return false;
                        }
                        flags[entry.pair] = true;
                        return true;
                    });

                    commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                    });

                }


            }
        });

    } catch (error) {

    }
}




router.route('/').get(getData);
module.exports = router;

