const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.bitfinex.com/v1/tickers?symbols'
        }

        request(options, function (error, response, body) {
            if (error) {
               // console.log(error)
            } else {

                if (body) {


                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var cryptoData = JSON.parse(body.toString());
					if(cryptoData.hasOwnProperty('error')){
						return false
					}
                    if (cryptoData) {
                        var ethCoin = cryptoData.find(function (element) {
                            if (element.pair == 'ETHUSD') {
                                return element;
                            }
                        });
						
                        var btcCoin = cryptoData.find(function (element) {
                            if (element.pair == 'BTCUSD') {
                                return element;
                            }
                        });
                      
                        commonCollection.find({ name: "bitfinex", date: dateString }, function (err, coindetail) {
                            var coinDetail = coindetail;

                            var pairName, convertUsd, openPrice;
						//	console.log(err)
                            cryptoData.map((item) => {
                                var coinPair = (item.pair).substr(item.pair.length - 3);
                                if (coinPair == 'USD') {
                                    convertUsd = 1
                                    pairName = (item.pair).toLowerCase();
                                    if(coinDetail){
										if (coinDetail.length > 0) {

                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });

                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last_price * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last_price * convertUsd;
                                    }
									}else {
                                        openPrice = item.last_price * convertUsd;
                                    }

                                } else if (coinPair == 'ETH') {
                                    pairName = (item.pair).replace(/eth/gi, "usd").toLowerCase();
									if(ethCoin){
										convertUsd = ethCoin.last_price;
                                    if(coinDetail){
										if (coinDetail.length > 0) {

                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });

                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last_price * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last_price * convertUsd;
                                    }
									}else {
                                        openPrice = item.last_price * convertUsd;
                                    }
									}
                                    
                                } else if (coinPair == 'BTC') {
                                    pairName = (item.pair).replace(/btc/gi, "usd").toLowerCase();   
									  if(btcCoin)   {
										convertUsd = btcCoin.last_price;
                                    if(coinDetail){
										if (coinDetail.length > 0) {

                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });

                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last_price * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last_price * convertUsd;
                                    }
									}else {
                                        openPrice = item.last_price * convertUsd;
                                    }
									}            
                                    
                                   
                                } else {
                                    pairName = false;
                                }
                                if (pairName) {

                                    var obj = {
                                        name: "bitfinex",
                                        pair: pairName,
                                        volume: item.volume * convertUsd,
                                        price: item.last_price * convertUsd,
                                        high: item.high * convertUsd,
                                        open: openPrice,
                                        close: item.last_price * convertUsd,
                                        low: item.low * convertUsd,
                                        datestamp: datestamp,
                                        date: dateString,
										lastRecord: true
                                    }
                                    crptoArray.push(obj)


                                }

                            })

                            var flags = {};

                            var coinUniqueData = crptoArray.filter(function (entry) {
                                if (flags[entry.pair]) {
                                    return false;
                                }
                                flags[entry.pair] = true;
                                return true;
                            });
                            
                            commonCollection.insertMany(coinUniqueData, function (error, docs) {

                            });
                        })
                    }

                }
            }
        });

    } catch (error) {
		//console.log(error)
    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;

