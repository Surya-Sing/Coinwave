const currencyCollection = require('../models/currency')
const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");


const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.coinone.co.kr/ticker/?currency=all'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    var pairName, convertUsd, openPrice;
                    currencyCollection.findOne({}, function (err, currencyData) {
                        convertUsd = currencyData.currency[0].USDKRW;
                        commonCollection.find({ name: "coinone", date: dateString }, function (err, coindetail) {
                            var coinDetail = coindetail;
                            for (item in CoinData) {
                                pairName = (item)+ "usd";
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].last) * convertUsd;
                                    }

                                } else {
                                    openPrice = Number(CoinData[item].last) * convertUsd;
                                }

                                var obj = {
                                    name: "coinone",
                                    pair: pairName,
                                    volume: Number(CoinData[item].volume) * convertUsd,
                                    price: Number(CoinData[item].last) * convertUsd,
                                    high: CoinData[item].high * convertUsd,
                                    open: openPrice,
                                    close: Number(CoinData[item].last) * convertUsd,
                                    low: Number(CoinData[item].low) * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString
                                }

                                crptoArray.push(obj)

                            }

                            var flags = {};

                            var coinUniqueData = crptoArray.filter(function (entry) {
                                if (flags[entry.pair]) {
                                    return false;
                                }
                                flags[entry.pair] = true;
                                return true;
                            });
                            return res.send(coinUniqueData)
                            commonCollection.insertMany(coinUniqueData, function (error, docs) {

                            });
                        })

                    })
                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;
