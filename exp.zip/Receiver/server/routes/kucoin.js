const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.kucoin.com/v1/market/open/symbols'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
              
                if (body) {


                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
					try{
					var cryptoData = JSON.parse(body.toString());
					}catch(e){
						return false;
					}
                    var kuCoinaData = cryptoData.data;
					
					if(kuCoinaData){
                    var ethCoin = kuCoinaData.find(function (element) {
                        if (element.symbol == 'ETH-USDT') {
                            return element;
                        }
                    });
                    var btcCoin = kuCoinaData.find(function (element) {
                        if (element.symbol == 'BTC-USDT') {
                            return element;
                        }
                    });
                    commonCollection.find({ name: "kuCoin", date: dateString }, function (err, coindetail) {
						if(err || !coinDetail){
							//console.log(err)
							return
						}
						
                        var coinDetail = coinDetail;
                        var pairName, convertUsd, openPrice;
                        kuCoinaData.map((item) => {

                            var coinPair = (item.symbol).split('-');
                            if (coinPair[1] == 'USDT') {
                                convertUsd = 1
                                pairName = (item.symbol).replace(/-usdt/gi, "usd").toLowerCase();
                               if(coinDetail){
								    if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }

                                } else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }
							   }else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }

                            } else if (coinPair[1] == 'ETH') {
								if(ethCoin){
									 pairName = (item.symbol).replace(/-eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.lastDealPrice;
                                 if(coinDetail){
								    if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }

                                } else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }
							   }else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }
								}
                               
                            } else if (coinPair[1] == 'BTC') {
								if(btcCoin){
									 pairName = (item.symbol).replace(/-btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.lastDealPrice;
                              if(coinDetail){
								    if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }

                                } else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }
							   }else {
                                    openPrice = item.lastDealPrice * convertUsd;
                                }
								}
                               
                               

                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "kuCoin",
                                    pair: pairName,
                                    volume: item.vol * convertUsd,
                                    price: item.lastDealPrice * convertUsd,
                                    high: item.high * convertUsd,
                                    open: openPrice,
                                    close: item.lastDealPrice * convertUsd,
                                    low: item.low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true 
                                }
                                crptoArray.push(obj)


                            }

                        })

                        var flags = {};

                        var kuCoinaUniqueData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });

                        commonCollection.insertMany(kuCoinaUniqueData, function (error, docs) {
							//console.log("OK")
                        });
                    })
                }

				}
            }
        });

    } catch (error) {
    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;

// kuCoinaUniqueData.map((desc) => {
//     console.log(desc)
//     var symbolOnly = desc.pair.replace(/usd/, '').toUpperCase()

//     var nameObj = {
//         "symbol": desc.pair,
//         "name": coinNames[symbolOnly] ? coinNames[symbolOnly] : "name",
//         "image": coinNames[symbolOnly] + ".png",
//     }
//     var crypto = new CryptoName(nameObj);
//     crypto.save(function (err) {
//         if (err) {

//         }
//         else {
//             res.send({
//                 message: 'Crypto saved successfully.'
//             });
//         }

//     });
// })