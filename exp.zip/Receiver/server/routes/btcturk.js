const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://www.btcturk.com/api/ticker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date))
                    var coinData = JSON.parse(body.toString());
                    var btcCoin = coinData.find(function (element) {
                        if (element.pair == 'USDTTRY') {
                            return element;
                        }
                    });

                    var pairName, convertUsd; var crptoArray = [];
                    coinData.map((item) => {

                        var coinPair = item.denominatorsymbol;
                        if (coinPair == 'USDT') {

                            pairName = (item.pair).replace(/usdt/gi, "usd").toLowerCase();
                            convertUsd = 1
                            var obj = {
                                name: "btcturk",
                                pair: pairName,
                                volume: item.volume * convertUsd,
                                price: item.last * convertUsd,
                                high: item.high * convertUsd,
                                open: item.open * convertUsd,
                                close: item.last * convertUsd,
                                low: item.low * convertUsd,
                                datestamp: datestamp
                            }

                            crptoArray.push(obj)

                        } else if (coinPair == 'TRY') {
                            pairName = (item.pair).replace(/try/gi, "usd").toLowerCase();
                            convertUsd =1/btcCoin.last;
                            var obj = {
                                name: "btcturk",
                                pair: pairName,
                                volume: item.volume * convertUsd,
                                price: item.last * convertUsd,
                                high: item.high * convertUsd,
                                open: item.open * convertUsd,
                                close: item.last * convertUsd,
                                low: item.low * convertUsd,
                                datestamp: datestamp
                            }

                            crptoArray.push(obj)

                        }

                    })
                    var flags = {};
                    var cryptopiaUniqueData = crptoArray.filter(function (entry) {
                        if (entry.pair == 'usdtusd') {
                            return false;
                        }
                        if (flags[entry.pair]) {
                            return false;
                        }
                        flags[entry.pair] = true;
                        return true;
                    });
                    return res.send(cryptopiaUniqueData)
                    commonCollection.insertMany(cryptopiaUniqueData, function (error, docs) {
                    });

                }
            }
        });

    } catch (error) {
    }
}

router.route('/').get(getData);
module.exports = router;
module.exports.getData = getData;


