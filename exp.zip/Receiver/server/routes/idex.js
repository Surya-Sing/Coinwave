const commonCollection = require('../models/common');
// const idexLocal = require('../models/idex');
const express = require('express');
const http = require("https");
const router = express.Router();
const request = require("request");

const getData = (req, res) => {

    var options = {
        method: 'GET',
        url: 'https://api.idex.market/returnTicker/'
    };
    request(options, function (error, response, body) {
        if (error) {
            console.log(error)
        }
        else {
            var date = new Date(),
            hours = date.getHours(),
            minutes = date.getMinutes();
            var dataIdex = JSON.parse(body.toString());
            for (var key in dataIdex) {
                    var pairName = key.replace('_', '').toLowerCase();
                    var dataObj = {
                        name: "idex",
                        pair: pairName.toLowerCase(),
                        volume: dataIdex[key].baseVolume=="N/A"?0:dataIdex[key].baseVolume,
                        price: dataIdex[key].last=="N/A"?0:dataIdex[key].last,
                        low: dataIdex[key].low=="N/A"?0:dataIdex[key].low,
                        high: dataIdex[key].high=="N/A"?0:dataIdex[key].high,
                        date: date.toLocaleDateString(),
                        open:dataIdex[key].last!="N/A"?(hours==12?dataIdex[key].last:0):0,
                        close:dataIdex[key].last!="N/A"?0:dataIdex[key].last,
                    }
                console.log(dataObj);
                var  idexDetails = new commonCollection(dataObj);
                idexDetails.save(function (err, data) {   
                    if (err) {
                        // console.log("ERROR: "+err)
                    } else {
                        // console.log("Idex Added successfully")
                    }
                })

                
                }
        }
        
    });
}
const getExchange = (req, res) => {
    idexLocal.find({}, function (err, data) {
    res.send(data)
    })
}


router.route('/').get(getData);
router.route('/exchange').get(getExchange)
module.exports = router;
module.exports.getData = getData;

