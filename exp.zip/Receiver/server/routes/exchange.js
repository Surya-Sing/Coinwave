

const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();
const coinDetailCollection = require('../models/coinDetails');
const minuteCollection = require('../models/minuteData');
const dayCollection = require('../models/dayData');
const exchangeCollection = require('../models/exchangeSummary');

function getSummaryExchange(req, res) {

    var aggQuery = [
        {
            $match: {
				"lastRecord" : true
                // $and: [
                    // { "datestamp": { $gte: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 2)).setSeconds(0)) } },
                    // { "datestamp": { $lt: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 1)).setSeconds(0)) } }
                // ]
            }
        },
        { $group: { _id: "$name", name: { $first: "$name" },volume: { $sum: "$volume" }, "noOfcoins": { "$sum": 1 }, }  },
        {
            $project: {
                _id: 0,
                "name":1,
                "volume": 1,
                "noOfcoins":1
            }
        }
    ]
    commonCollection.aggregate(aggQuery, function (err, data)  { 
       
        exchangeCollection.insertMany(data)
        .then(function (docs) {
         // console.log("Exchange added")
        })
        .catch(function (err) {
            //console.log("Exchange error")
        });
    })

}

const dayChange = (cb) => {

    // 
    minuteCollection.aggregate([
        { $match: { "datestamp": { $gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } } },//TODO
        { $sort: { price: 1 } },  //TODO  
        { $group: { _id: "$pair", dayVolume: { $avg: "$volume" }, "count": { "$sum": 1 }, lowestPrice: { $first: "$price" }, highestPrice: { $last: "$price" } } },
        {
            $project: {
                _id: 1,
                "highestPrice": 1,
                "dayVolume": 1,
                "count": 1,
                "lowestPrice": 1
            }
        }
    ], function (err, data) {
        cb(data)
    })
}

function deleteMinuteData() {
    
        var threeDaysAgo = new Date(new Date().setDate(new Date().getDate() - 3));
    
        minuteCollection.deleteMany({ datestamp: { $lt: threeDaysAgo } }, function (err) {
            console.log("Data  deleted from minute collection")
        })
    }
	
const SevenDayChange = (cb) => {

    var startDate = new Date();
    startDate.setDate(new Date().getDate() - 7);
    startDate.setSeconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);

    var dateMidnight = new Date(startDate);
    dateMidnight.setHours(23);
    dateMidnight.setMinutes(59);
    dateMidnight.setSeconds(59);
    var aggQuery = [
        {
            $match: {
                $and: [
                    { "datestamp": { $gte: startDate } },
                    { "datestamp": { $lt: dateMidnight } }
                ]
            }
        },

        { $group: { _id: "$pair", price: { $avg: "$price" } } }
    ]
    // console.log(aggQuery)
    minuteCollection.aggregate(aggQuery, function (err, data) {
         
        cb(data)
    })
}

const exchangeSummary = (req, res) => {
    coinDetailCollection.aggregate([

        { $group: { _id: "$name", total: { $sum: "$volume" }, "count": { "$sum": 1 } } },
        {
            $project: {
                _id: 1,
                "total": 1,
                "count": 1
            }
        }
    ], function (err, data) {
        if (err || !data) {
            res.status(404).send("No data")
        }
        else {
            var result = []
            let sum = 0;
            data.map((item) => {
                sum += item.total
            })

            data.map((item) => {
                let percent = (((item.total / sum)) * 100).toFixed(2);
                result.push({ name: item._id, volume: item.total, volumePercent: percent, NoOfCoins: item.count })
            })
            res.send(result)
        }
    })
}

const getusd = (req, res) => {
//console.log("Getting call GETUSD API")
    var matchArray = [];
	var aggreQuery =        [

          
            {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" }
                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image"
                }
            }
        ];
    if (req.body.hasOwnProperty('filter')) {
        var filterObj = req.body.filter;
        for (key in filterObj) {
            matchArray.push({ [key]: { $gte: filterObj[key].from } })
            matchArray.push({ [key]: { $lt: filterObj[key].to } })
        }
		aggreQuery.unshift( {
                $match: {
                    $and: matchArray
                }
            })
        //console.log(matchArray)
    }
	
	
    var coinbase = 'usd';  //req.params.id;
    var likeString = new RegExp(coinbase, 'i')

    coinDetailCollection.aggregate(aggreQuery
    ).exec(function (err, data) {
        dayChange(function (changes) {
            var result = [];
            // console.log(changes)
            marketCap(function (cap) {
				//console.log(cap);
				
                data.map((item) => {
                    changes.map((dec) => {
                        finalObj = JSON.parse(JSON.stringify(item));
                        if (item.pair == dec._id) {
                            //   var symbolName = (item.pair).substring(0, 3);
                            var symbolName = (item.name).toLowerCase();


                            if (cap) {
                                for (key in cap) {
                                    // console.log(cap[key].name)

                                    var symbolCap = (cap[key].name).toLowerCase();

                                    if (symbolCap == symbolName) {
                                        //console.log(cap[key].circulating_supply)
                                        finalObj["marketCapValue"] = (cap[key].circulating_supply * item.price).toFixed(2);
                                    }
                                }
                            }

                            finalObj["dayVolume"] = dec.dayVolume.toFixed(2),
                                finalObj["lowestPrice"] = dec.lowestPrice.toFixed(2),
                                finalObj["highestPrice"] = dec.highestPrice.toFixed(2)

                            result.push(finalObj)
                            //console.log(finalObj)
                        }
                    })
                })
                res.send(result)
            })
        })
    })

}


const getParticularCoin = (req, res) => {
    // coinDetailCollection.find({pair: /usd$/},function(err,data){
    //     res.send(data)
    // }).sort({_id:1})
    var coinbase = 'usd';  //req.params.id;
    var likeString = new RegExp(coinbase, 'i')
    coinDetailCollection.aggregate(
        [
            {
                $match: { "pair": req.params.id }
            },
            {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" }
                }
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1
                }
            }
        ]
    ).exec(function (err, data) {
        res.send(data)
    })

}

const getLastSecData = (req, res) => {
    //console.log(req.body.pair)
    if (req.body.pair) {

        coinDetailCollection.aggregate([

            {
                $project: {
                    _id: 1,
                    pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1,
                    secs: { $second: '$datestamp' }
                }
            },
            { $match: { pair: req.body.pair } },
            {
                "$sort": {
                    "_id": -1
                }
            },
            {
                "$limit": 1
            }

        ],
            //commonCollection.find({ pair: req.body.pair }, { _id: 0, pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, createdDateTime: 1 },
            function (err, data) {
                //  console.log(err)
                if (data) {
                    var result = []
                    data.map((item) => {
                        finalObj = JSON.parse(JSON.stringify(item));
                        finalObj.time = new Date(item.datestamp).valueOf()
                        delete finalObj.datestamp;
                        result.push(finalObj)
                    })

                    res.send(result)
                }

            })
    } else {
        res.status(404).send("Please send valid pair to proceed")
    }


}

const getChart = (req, res) => {
    //console.log(req.body.pair)
    if (req.body.pair) {

        minuteCollection.aggregate([
            {
                $project: {
                    _id: 1,
                    pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1,
                    secs: { $second: '$datestamp' }
                }
            },
            { $match: {  pair: req.body.pair } }
        ],
            //commonCollection.find({ pair: req.body.pair }, { _id: 0, pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, createdDateTime: 1 },
            function (err, data) {
                if (data) {
                    var result = []
                    data.map((item) => {
                        finalObj = JSON.parse(JSON.stringify(item));
                        finalObj.time = new Date(item.datestamp).valueOf()
                        delete finalObj.datestamp;
                        result.push(finalObj)
                    })

                    res.send(result)
                }

            })
    } else {
        res.status(404).send("Please send valid pair to proceed")
    }


}


const coinDetails = (req, res) => {
    try {
		
        commonCollection.aggregate([
            { $match: { lastRecord: true } },
            { $group: { _id: "$pair", price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
            {
                $project: {
                    _id: 1,
                    "price": 1,
                    "count": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "open": 1,
                    "close": 1,
                    "datestamp": 1
                }
            }
        ], function (err, docs) {
			
            if (err || !docs) {
                // res.status(404).send("No data")
            }
            else {
                var totalRecords = docs.length;
                var count = 0;

                marketCap(function (cap) {
                    docs.map((data) => {
                        count++
                        var symbolOnly =data._id.replace(/usd/gi, "")
                        var symbolName = symbolOnly;
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                       var marketCapValue = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * data.price);
                        var change, dayPricePercent, dayPrice, dayPriceStatus;
                        coinDetailCollection.findOne({ pair: data._id }).sort({ _id: -1 }).exec(function (err, post) {

                            if (post) {

                                if (post.price < data.price) {
                                    change = 'true';
                                } else if (post.price > data.price) {
                                    change = 'false';
                                }
                                else if (post.price == data.price) {
                                    change = post.priceStatus;
                                }
                                else {
                                    change = 'NC';
                                }
                            } else {
                                change = 'NC';
                            }
                            dayCollection.aggregate([
                                {
                                    $match:
                                    { pair: data._id }
                                },
                                { $sort: { _id: -1 } },
                                { $limit: 7 },
                                {
                                    $group: {
                                        _id: "$pair", pair: { $last: "$pair" }, dayPrice: { $first: "$price" }, weeklyPrice: { $last: "$price" }, volume: { $first: "$volume" }
                                        , highestPrice: { $first: "$high" }, lowestPrice: { $first: "$low" }
                                    }
                                }
                            ]).exec(function (err, days) {

                                var daysdata = days[0];

                                var latestPrice = Math.floor(data.price * 100) / 100;

                                if (daysdata) {
                                    var weakPrice = Math.floor(daysdata.weeklyPrice * 100) / 100;
                                    var oneDayPrice = Math.floor(daysdata.dayPrice * 100) / 100;
                                    var weeklyChange, weeklyChangeStatus, weeklyChangePercent;
                                    var highPrice = daysdata.highestPrice;
                                    var lowPrice = daysdata.lowestPrice;
                                    weeklyChange = Math.abs(latestPrice - weakPrice); //TODO
                                    if (weakPrice < latestPrice) {
                                        weeklyChangeStatus = 'true'
                                        weeklyChangePercent = (latestPrice / weakPrice)
                                    } else if (weakPrice > latestPrice) {
                                        weeklyChangePercent = (weakPrice / latestPrice)
                                        weeklyChangeStatus = 'false'
                                    } else {
                                        weeklyChangePercent = 0
                                        weeklyChangeStatus = 'NC'
                                    }

                                    dayPrice = Math.abs(data.price - daysdata.dayPrice)
                                    var dayVolume = daysdata.volume;
                                    //console.log(dayVolume)
                                    if (oneDayPrice < latestPrice) {
                                        dayPricePercent = ((latestPrice / oneDayPrice))
                                        dayPriceStatus = 'true';
                                    } else if (oneDayPrice > latestPrice) {
                                        dayPricePercent = ((oneDayPrice / latestPrice))
                                        dayPriceStatus = 'false';
                                    }
                                    else {
                                        dayPricePercent = 0
                                        dayPriceStatus = 'NC';
                                    }

                                } else {
                                    weeklyChange = 0;
                                    dayPrice = 0;
                                    dayPricePercent = 0;
                                    dayPriceStatus = 'NC';
                                    weeklyChangePercent = 0
                                    weeklyChangeStatus = 'NC'
                                    var highPrice = data.price;
                                    var lowPrice = data.price;
                                }
								if(weeklyChangePercent == 'Infinity'){
									weeklyChangePercent=0
								}
								if(dayPricePercent == 'Infinity'){
									dayPricePercent=0
								}
								
                                var details = new coinDetailCollection({ pair: data._id, price: data.price, dayVolume: dayVolume, volume: data.volume, highestPrice: highPrice, high: data.high, low: data.low, lowestPrice: lowPrice, open: data.open, close: data.close, priceStatus: change, datestamp: data.datestamp, weeklyChange: weeklyChange, weeklyChangeStatus: weeklyChangeStatus, dayPricePercent: dayPricePercent, weeklyChangePercent: weeklyChangePercent, dayPrice: dayPrice, dayPriceStatus: dayPriceStatus,marketCapValue:marketCapValue })
								//console.log(details)
                                details.save(function (error, detail) {
                                    if (totalRecords == count) {
                                        commonCollection.updateMany({ lastRecord: true },
                                            { "$set": { "lastRecord": false } }
                                        ).exec(function (err, book) {

                                        });
                                    }
                                })
                            })

                        });

                    })
                })
            }
        })
    }
    catch (e) {

    }
}

const coinDetailsPrev = (req, res) => {
	try{
		commonCollection.aggregate([
        { $match: { lastRecord: true } },
        { $group: { _id: "$pair", price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
        {
            $project: {
                _id: 1,
                "price": 1,
                "count": 1,
                "low": 1,
                "high": 1,
                "volume": 1,
                "open": 1,
                "close": 1,
                "datestamp": 1
            }
        }
    ], function (err, docs) {
        if (err || !docs) {
            // res.status(404).send("No data")
        }
        else {
			 var totalRecords = docs.length;
			 var count = 0;
            docs.map((data) => {
                 count++

                var change, dayPricePercent, dayPrice, dayPriceStatus;
                coinDetailCollection.findOne({ pair: data._id }).sort({ _id: -1 }).exec(function (err, post) {

                    if (post) {

                        if (post.price < data.price) {
                            change = 'true';
                        } else if (post.price > data.price) {
                            change = 'false';
                        } 
						else if (post.price ==  data.price) {
                            change =post.priceStatus;
                        } 
						else {
                            change = 'NC';
                        }
                    } else {
                        change = 'NC';
                    }
                    dayCollection.aggregate([
                        {
                            $match:
                            { pair: data._id }
                        },
                        { $sort: { _id: -1 } },
                        { $limit: 7 },
                        {
                            $group: {
                                _id: "$pair", pair: { $last: "$pair" }, dayPrice: { $first: "$price" }, weeklyPrice: { $last: "$price" }, volume: { $first: "$volume" }
                                , highestPrice: { $first: "$high" }, lowestPrice: { $first: "$low" }
                            }
                        }
                    ]).exec(function (err, days) {
						
						var daysdata = days[0];
					
                        var latestPrice = Math.floor(data.price * 100) / 100;
						
                      

                        if (daysdata) {
							  var weakPrice = Math.floor(daysdata.weeklyPrice * 100) / 100;
                             var oneDayPrice = Math.floor(daysdata.dayPrice * 100) / 100;
                            var weeklyChange, weeklyChangeStatus, weeklyChangePercent;
							var highPrice = daysdata.highestPrice;
							var lowPrice = daysdata.lowestPrice;
                            weeklyChange = Math.abs(latestPrice - weakPrice); //TODO
                            if (weakPrice < latestPrice) {
                                weeklyChangeStatus = 'true'
                                weeklyChangePercent = (latestPrice / weakPrice)
                            } else if (weakPrice > latestPrice) {
                                weeklyChangePercent = (weakPrice / latestPrice)
                                weeklyChangeStatus = 'false'
                            } else {
                                weeklyChangePercent = 0
                                weeklyChangeStatus = 'NC'
                            }
						
                            dayPrice = Math.abs(data.price - daysdata.dayPrice)
                            var dayVolume = daysdata.volume;
							//console.log(dayVolume)
                            if (oneDayPrice < latestPrice) {
                                dayPricePercent = ((latestPrice / oneDayPrice))
                                dayPriceStatus = 'true';
                            } else if (oneDayPrice > latestPrice) {
                                dayPricePercent = ((oneDayPrice / latestPrice))
                                dayPriceStatus = 'false';
                            }
							else {
                                dayPricePercent = 0
                                dayPriceStatus = 'NC';
                            }

                        } else {
							weeklyChange= 0;
                            dayPrice = 0;
                            dayPricePercent = 0;
                            dayPriceStatus = 'NC';
							weeklyChangePercent = 0
                            weeklyChangeStatus = 'NC'
							var highPrice = data.price;
							var lowPrice =  data.price;
                        }
                        var details = new coinDetailCollection({ pair: data._id, price: data.price, dayVolume: dayVolume, volume: data.volume, highestPrice: highPrice, high: data.high,  low: data.low,lowestPrice: lowPrice, open: data.open, close: data.close, priceStatus: change, datestamp: data.datestamp, weeklyChange: weeklyChange, weeklyChangeStatus: weeklyChangeStatus, dayPricePercent: dayPricePercent, weeklyChangePercent: weeklyChangePercent, dayPrice: dayPrice, dayPriceStatus: dayPriceStatus })                       
					   details.save(function (error, detail) {
						  // console.log("success")
						   if (totalRecords == count) {
                                commonCollection.updateMany({ lastRecord: true },
                                    { "$set": { "lastRecord": false } }
                                ).exec(function (err, book) {

                                });
                            }
                        })
                    })

                });

            })
        }
    })
	}
    catch(e){
		
	}
}


function marketCap(cb) {
    var options = {
        method: 'GET',
        url: 'https://api.coinmarketcap.com/v2/ticker/',
        json: true
    };

    request(options, function (error, response, body) {
        if (error) {
          //  console.log(error)
        } else {
             var data = body.data;
            var result = [];

            for (item in data) {
                result.push({ name: (data[item].symbol).toLowerCase(), circulating_supply: data[item].circulating_supply })

            }
            cb(result)
            //cb(body.data)
        }
    });
}

function deleteCoinRawData() {

    var twoMinuteAgo = new Date( Date.now() - 2000 * 60 );

    commonCollection.remove({datestamp : {$lt : twoMinuteAgo}}, function (err) {
       // console.log("Data updated in new collection and deleted from old collection")
    })
    

    // commonCollection.deleteMany({ lastRecord: false }, function (err) {
    //     console.log("Data updated in new collection and deleted from old collection")
    // })
}

function deleteCoinDetailData() {

    var twoMinuteAgo = new Date( Date.now() -  5000 * 60);

    coinDetailCollection.remove({datestamp : {$lt : twoMinuteAgo}}, function (err) {
     //   console.log("Data updated in minute collection and deleted from old collection")
    })
    

    // commonCollection.deleteMany({ lastRecord: false }, function (err) {
    //     console.log("Data updated in new collection and deleted from old collection")
    // })
}

function getMinuteData(req, res) {

    var aggQuery = [
        {
            $match: {
                $and: [
                    { "datestamp": { $gte: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 2)).setSeconds(0)) } },
                    { "datestamp": { $lt: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 1)).setSeconds(0)) } }
                ]
            }
        },
        { $group: { _id: "$pair", pair: { $last: "$pair" }, price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
        {
            $project: {
                "_id": 0,
                "price": 1,
                "pair": 1,
                "low": 1,
                "high": 1,
                "volume": 1,
                "open": 1,
                "close": 1,
                "datestamp": 1

            }

        }

    ]
    coinDetailCollection.aggregate(aggQuery, function (err, data) {
        if (data) {
           // console.log(data)
            var count = 0;
            data.map(function (item) {
                 //console.log(item)
                var minuteData = new minuteCollection(item);
                minuteData.save(function (error, detail) {})
            })
        }

    })

}

function getMax(req, res) {
    var aggQuery = [
        {
            $group:
            {
                _id: null,
                maxPrice: { $max: "$price" }
            }
        }
    ]
    coinDetailCollection.aggregate(aggQuery, function (err, data) {
        res.send(data)
    })



}



function getDayData(req, res) {
    var startDate = new Date();
    startDate.setDate(new Date().getDate() - 1);
    startDate.setSeconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);

    var dateMidnight = new Date()
    dateMidnight.setDate(new Date().getDate() - 1);
    dateMidnight.setHours(23);
    dateMidnight.setMinutes(59);
    dateMidnight.setSeconds(59);

    var aggQuery = [
        {
            $match: {
                $and: [
                    { "datestamp": { $gte: startDate } },
                    { "datestamp": { $lt: dateMidnight } }
                ]
            }
        },
        { $group: { _id: "$pair", pair: { $last: "$pair" }, price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
        {
            $project: {
                "_id": 0,
                "price": 1,
                "pair": 1,
                "low": 1,
                "high": 1,
                "volume": 1,
                "open": 1,
                "close": 1,
                "datestamp": 1

            }

        }

    ]
    minuteCollection.aggregate(aggQuery, function (err, data) {
		
		if(err){
			console.log("err")
			console.log(err)
		}
        if (data) {
            dayCollection.insertMany(data)
                .then(function (docs) {
                   
                })
                .catch(function (err) {
                    console.log(err)
                });
            return
            var count = 0;
            data.map(function (item) {
                // console.log(item)
                var minuteData = new minuteCollection(item);
                minuteData.save(function (error, detail) {
                    
                })
            })
        }

    })

}
router.route('/getMax').get(getMax)
router.route('/exchangeSummary').get(exchangeSummary)
router.route('/coinDetails').get(coinDetails)
router.route('/getusd/:id').get(getParticularCoin)

router.route('/SevenDayChange').get(SevenDayChange)

router.route('/getLastSecData').post(getLastSecData)
router.route('/getusd').post(getusd)
router.route('/getChart').post(getChart)
router.route('/dayChange').post(dayChange)
router.route('/getMinuteData').get(getMinuteData)
router.route('/getDayData').get(getDayData)
module.exports = router;
module.exports.coinDetails = coinDetails; 
module.exports.deleteCoinRawData = deleteCoinRawData;
module.exports.deleteCoinDetailData = deleteCoinDetailData;
module.exports.getMinuteData = getMinuteData;
module.exports.getDayData = getDayData;
module.exports.deleteMinuteData = deleteMinuteData;
module.exports.getSummaryExchange = getSummaryExchange;



