# Receiver
receive data from all exchanges
