
const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.livecoin.net/exchange/ticker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {

                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var cryptoData = JSON.parse(body.toString());
                    var kuCoinaData = cryptoData;

                    if (kuCoinaData) {
                        var ethCoin = kuCoinaData.find(function (element) {
                            if (element.symbol == 'ETH/USD') {
                                return element;
                            }
                        });
                        var btcCoin = kuCoinaData.find(function (element) {
                            if (element.symbol == 'BTC/USD') {
                                return element;
                            }
                        });
                        commonCollection.find({ name: "livecoin", date: dateString }, function (err, coindetail) {
                            var coinDetail = coindetail;

                            var pairName, convertUsd, openPrice;
                            kuCoinaData.map((item) => {

                                var coinPair = (item.symbol).split('/');
                                if (coinPair[1] == 'USD') {
                                    convertUsd = 1
                                    pairName = (item.symbol).replace(/\/usd/gi, "usd").toLowerCase();
                                    if (coinDetail.length > 0) {

                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });

                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last * convertUsd;
                                    }

                                } else if (coinPair[1] == 'ETH') {
                                    pairName = (item.symbol).replace(/\/eth/gi, "usd").toLowerCase();
                                    convertUsd = ethCoin.last;
                                    if (coinDetail.length > 0) {
                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });
                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last * convertUsd;
                                    }
                                } else if (coinPair[1] == 'BTC') {
                                    pairName = (item.symbol).replace(/\/btc/gi, "usd").toLowerCase();
                                    convertUsd = btcCoin.last;
                                    if (coinDetail.length > 0) {
                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });
                                        if (openCalc) {
                                            openPrice = openCalc.open
                                        } else {
                                            openPrice = item.last * convertUsd;
                                        }

                                    } else {
                                        openPrice = item.last * convertUsd;
                                    }
                                    // console.log(openPrice)

                                } else {
                                    pairName = false;
                                }
                                if (pairName) {

                                    var obj = {
                                        name: "livecoin",
                                        pair: pairName,
                                        volume: item.volume * convertUsd,
                                        price: item.last * convertUsd,
                                        high: item.high * convertUsd,
                                        open: openPrice,
                                        close: item.last * convertUsd,
                                        low: item.low * convertUsd,
                                        datestamp: datestamp,
                                        date: dateString
                                    }
                                    
                                    crptoArray.push(obj)


                                }

                            })

                            var flags = {};
                            var livecoinUniqueData = crptoArray.filter(function (entry) {
                                if (flags[entry.pair]) {
                                    return false;
                                }
                                flags[entry.pair] = true;
                                return true;
                            });
                            livecoinUniqueData.map((desc) => {
                                console.log(desc)
                                var symbolOnly = desc.pair.replace(/usd/, '').toUpperCase()
    
                                var nameObj = {
                                    "symbol": desc.pair,
                                    "name": coinNames[symbolOnly] ? coinNames[symbolOnly] : "name",
                                    "image": coinNames[symbolOnly] + ".png",
                                }
                                var crypto = new CryptoName(nameObj);
                                crypto.save(function (err) {
                                    if (err) {
    
                                    }
                                    else {
                                        res.send({
                                            message: 'Crypto saved successfully.'
                                        });
                                    }
    
                                });
                            })
                          // return res.send(livecoinUniqueData)
                            // commonCollection.insertMany(livecoinUniqueData, function (error, docs) {
                                
                            // });
                        })
                    }

                }
            }
        });

    } catch (error) {
    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;

// kuCoinaUniqueData.map((desc) => {
//     console.log(desc)
//     var symbolOnly = desc.pair.replace(/usd/, '').toUpperCase()

//     var nameObj = {
//         "symbol": desc.pair,
//         "name": coinNames[symbolOnly] ? coinNames[symbolOnly] : "name",
//         "image": coinNames[symbolOnly] + ".png",
//     }
//     var crypto = new CryptoName(nameObj);
//     crypto.save(function (err) {
//         if (err) {

//         }
//         else {
//             res.send({
//                 message: 'Crypto saved successfully.'
//             });
//         }

//     });
// })