// Server Configuration

const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const passport = require('passport');
const apiRoutes = express.Router();
const cors = require('cors');
const app = express();
var http = require("https");
var cron = require('node-cron');
const multipart = require('connect-multiparty');
const crypto = require('./server/routes/name')
const user = require('./server/routes/user');
const User = require('./server/models/user');

const acx = require('./server/routes/acx')
const binance = require('./server/routes/binance')
const bisq = require('./server/routes/bisq')
const bitfinex = require('./server/routes/bitfinex')
const bitsane = require('./server/routes/bitsane')
const bitso = require('./server/routes/bitso');
const bitstamp = require('./server/routes/bitstamp')
const bittrex = require('./server/routes/bittrex')
const btcTrade = require('./server/routes/btcTrade')
const btcturk = require('./server/routes/btcturk')
const cex = require('./server/routes/cex')
const coinbene = require('./server/routes/coinbene')
const coinex = require('./server/routes/coinex')
const coinone = require('./server/routes/coinone')
const cryptopia = require('./server/routes/cryptopia')
const exx = require('./server/routes/exx')
const gateIo = require('./server/routes/gateio')
const gatecoin = require('./server/routes/gatecoin')
const gdax = require('./server/routes/gdax')
const hitbtc = require('./server/routes/hitbtc')
const huobi = require('./server/routes/huobi')
const kucoin = require('./server/routes/kucoin')
const livecoin = require('./server/routes/livecoin')
const lykke = require('./server/routes/lykke')
const idex = require('./server/routes/idex')
const okcoin = require('./server/routes/okcoin')
const orebz = require('./server/routes/ore.bz')
const poloniex = require('./server/routes/poloniex')
const theRockTrading = require('./server/routes/theRockTrading')
const zbCom = require('./server/routes/zb-com')

const exchange = require('./server/routes/exchange')
var jsonData = require('./sample.json');
var jsonData1 = require('./sample1.json');


const db = require('./database');

require('dotenv').config()
require('./server/config/passport');


app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({
    limit: '1000mb'
}));

app.use(bodyParser.json({
    limit: '1000mb'
}));

app.use(bodyParser.json({
    type: 'application/vnd.api+json'
}));

app.use(passport.initialize());
app.use(multipart());
const enableCORS = function (request, response, next) {
    response.header('Access-Control-Allow-Origin', request.headers.origin);
    response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    response.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Date, X-Date');
    return next();
};



app.use(cors());
app.use(enableCORS);
//apply the routes to User Module
app.use('/user', user);
app.use('/crypto', crypto);

app.use('/exx', exx);


// route middleware to verify a token
apiRoutes.use(function (req, res, next) {

    // check header or url parameters or post parameters for token
    var token = req.body.token || req.query.token || req.headers['x-access-token'];

    if (token) {
        jwt.verify(token, tokenValue, function (err, decoded) {
            if (err) {
                return res.json({ success: false, message: 'Failed to authenticate token.' });
            } else {
                // if everything is good, save to request for use in other routes
                req.decoded = decoded;
                next();
            }
        });

    } else {
        // if there is no token return unauthorized error
        return res.status(403).send({
            success: false,
            message: 'No token provided.'
        });

    }
});


apiRoutes.get('/checkAuthentication', function (req, res) {
    res.end("done")
})

app.get('/getData', function (req, res) {
    res.send(jsonData);
})
app.get('/getJSON', function (req, res) {
    res.send(jsonData1);
})
// apply the routes to our application with the prefix /api

app.use('/api', apiRoutes);


function cronExchnages() {

    cron.schedule('0 0 0 * * *', function () {
        exchange.getDayData()
        //exchange.deleteMinuteData()
    });
    cron.schedule('*/2 * * * *', function () {
        binance.getData()
        cex.getData()
    })
    cron.schedule('* * * * *',  // ecery minute
        //cron.schedule('* * * * * *', //every second

        function () {

            cryptopia.getData()
            //coinbene.getData()
            kucoin.getData()
            hitbtc.getData()
            // bittrex.getData()
            // bitstamp.getData()
            //coinex.getData()
            //okcoin.getData()
            // gateIo.getData()
            // gdax.getData()
            // bitfinex.getData()
            //theRockTrading.getData()
            //exx.getData()
            exchange.coinDetails()

        });

    setTimeout(function () {

        //cron.schedule('0-59 * * * * *', 
        cron.schedule('*/5 * * * *',  // todo
            function () {

                //exchange.deleteCoinDetailData()
                exchange.deleteCoinRawData()
            });

    }, 2000);
    cron.schedule('* * * * *',
        function () {

            exchange.getMinuteData()
            //exchange.getSummaryExchange() //TODO
        });
    setTimeout(function () {
        cron.schedule('* * * * *',
            //cron.schedule('*/2 * * * *', //Todo
            function () {
                //exchange.deleteCoinDetailData()
            });
        cron.schedule('* * * * *',
            function () {
                //exchange.getMinuteData()
                //exchange.getSummaryExchange()
            });
    }, 60000);

}
cronExchnages()
module.exports = app;

app.timeout = 0;
app.listen(3000);
console.log('Server running at http://127.0.0.1:x' + 3000);


