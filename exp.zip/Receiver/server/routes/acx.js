const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");


const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://acx.io//api/v2/tickers.json'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    for (item in CoinData) {
                        
                        var coinPair = CoinData[item].name.split('/');

                        if (coinPair[1] == 'USDT') {
                            pairName = (CoinData[item].name).replace(/\/usdt/gi, "usd").toLowerCase();

                        }
                        else if (coinPair[1] == 'BTC') {
                            pairName = (CoinData[item].name).replace(/\/btc/gi, "usd").toLowerCase();

                        }
                        else {
                            pairName = false;
                        }
                        if (pairName) {
                        var obj = {
                            name: "acx",
                            pair: pairName,
                            volume: CoinData[item].ticker.vol,
                            price: CoinData[item].ticker.last,
                            high: CoinData[item].ticker.high,
                            open: CoinData[item].ticker.open,
                            close: CoinData[item].ticker.last,
                            low: CoinData[item].ticker.low,
                            datestamp: datestamp,
                            date: dateString
                        }
                        crptoArray.push(obj)
                    }

                      
                    }

                    var flags = {};
                    var UniqueCoinData = crptoArray.filter(function (entry) {
                        if (flags[entry.pair]) {
                            return false;
                        }
                        flags[entry.pair] = true;
                        return true;
                    });
                    commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                    });


                }
            }



        });

    } catch (error) {

    }
}



router.route('/').get(getData)


module.exports = router;
module.exports.getData = getData;

